<!DOCTYPE html>
<html lang="en">
<head>
  <title>DETAILS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
	
<body background="5.jpg"  >

<?php
	session_start();
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";



$conn = new mysqli($servername, $user, $pass, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

	$event_id=$_GET["id"];
	$_SESSION['event_id']=$event_id;
	

$sql1 = "SELECT * FROM events WHERE eventid='$event_id' ";
   $result = $conn->query($sql1);
	 while($array=mysqli_fetch_row($result)) 
		 
	{
		$var=$array[0];
	?>
	
	<div class="container">
  <div class="row">
    <div class="col-sm-8">
	

  <div><h3><b>EventId:</b></h3><?php echo $array[0]; ?></div><br>
  <div><h3><b>EventName:</b></h3><?php echo $array[1]; ?> </div><br>
  <div><h3><b>EventOrganizer:</b></h3><?php echo $array[2]; ?></div><br>
  <div><h3><b>Description:</b></h3><?php echo $array[3]; ?></div><br>
  <div><h3><b>Venue:</b></h3><?php echo $array[4]; ?></div><br>
  <div><h3><b>EventStartDate:</b></h3><?php echo $array[5]; ?></div><br>
  <div><h3><b>EventEndDate:</b></h3><?php echo $array[6]; ?></div><br>
  <div><h3><b>EventWebsiteURL:</b></h3><?php echo $array[7]; ?></div><br>
  <div><h3><b>TicketPrice:</b></h3><?php echo $array[8]; ?></div><br>
  <div><h3><b>ContactNo1:</b></h3><?php echo $array[9]; ?></div><br>
  <div><h3><b>ContactNo2:</b></h3><?php echo $array[10]; ?></div><br>
  <div><h3><b>ContactNo3:</b></h3><?php echo $array[11]; ?></div><br>
  <div><h3><b>SeatsAvailable:</b></h3><?php echo $array[12]; ?></div><br>
  <div><h3><b>TermsAndConditions:</b></h3><?php echo $array[13]; ?></div><br>
  <div><h3><b>BookingURL:</b></h3><?php echo $array[14]; ?></div><br>
	  </div>
	   <div class="col-sm-4">
	
  <div><h3><b>EventImage:</b></h3><br><img src= " <?php echo $array[15];?> " > </div><br>
	
		 
		      
		   <a href="login.php">BOOK TICKETS</a>
		
	  </div>
		</div>
	</div>
	<hr>
		<?php } 
$conn->close();
	?>
	
</body>
</html>
	
