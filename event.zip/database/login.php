<!DOCTYPE html>
<html lang="en">
<head>
  <title>LOGIN</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>



<body background="5.jpg"  >
<?php
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";



$conn = new mysqli($servername, $user, $pass, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

	
?>  
	  
	<div class="container">
  <div class="row">
    <div class="col-sm-6">
	
	
		<form action="login1.php" method="get">
			
			<h4>LogIn</h4>
		         <input type="text" name="username" placeholder="username"/><br>
		         <input type="password" name="password" placeholder="password"/><br>
			     <input type="submit" name="submit" value="submit"/>
	   </form>		
	</div>
	  <div class="col-sm-6">
		  <form action="signup.php" method="POST">
			  <h4>SignUp</h4>
		<input type="text" name="name" placeholder="name"/><br>
		<input type="text" name="lastname" placeholder="lastname"/><br>
		<input type="text" name="email" placeholder="email"/><br>
		<input type="text" name="phoneno" placeholder="phoneno"/><br>
		<input type="text" name="address"placeholder="address"/><br>
		<input type="text" name="username" placeholder="username"/><br>
		<input type="text" name="password" placeholder="password"/><br>
		<input type="text" name="status" placeholder="status"/><br>
		<input type="submit" name="submit" value="submit"/>
			</form>
		
	</div>
		</div>
	</div>
	
	
	
	
	  
</body>
</html>
