<?php
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";



$conn = new mysqli($servername, $user, $pass, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>