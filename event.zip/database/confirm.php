<html>
	
	
	<head>
		<style>
			
table{
    border: 1px solid black;
	width:500px;
}
		</style>
	</head>
<body  background="5.jpg">


		<div align="right">
		<a href="logout.php">LogOut</a>
		</div>
	


<?php
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";



$conn = new mysqli($servername, $user, $pass, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

$eid=$_SESSION['event_id'];
$memberid=$_SESSION['mid'];
$n=$_SESSION['n'];
$p=$_SESSION['p'];


$res=mysqli_query($conn,"select * from events where eventid='$eid'");
	while($array=mysqli_fetch_array($res)) {
		$eventname=$array[1];
		$eventstart=$array[5];
		$eventvenue=$array[4];
	}
	$re=mysqli_query($conn,"select * from members where id='$memberid'");
	while($arra=mysqli_fetch_array($re)) {
		$name=$arra[1];
		$email=$arra[3];
		$phone=$arra[4];
		$add=$arra[5];
	}
	?>
		<table align="center">
			<tr>
				<td><b><i><u>Booking Confirmation</u></i></b></td>
			</tr>
			<br>
		<tr>
			
		<td>Name:<?php echo $name ;?></td>
			</tr>
			<br>
			<tr>
		
	    <td>EventName:<?php echo $eventname ; ?></td>
			</tr>
			<br>
			<tr>
		<td>StartDate:<?php echo  $eventstart ; ?></td>
			</tr>
			<br>
			<tr>
		<td>No. Of Seats:<?php echo $n; ?></td>
			</tr>
			<br>
			<tr>
		<td>TotalPrice:<?php  echo $p; ?></td>
			</tr>
			<br>
			<tr>
	    <td>Venue:<?php echo $eventvenue ; ?></td>
		
		</tr>
		
	</table>
	
	<?php $var=$name;?>
	
	<table align="center">
		<tr>
			<td><b><i><u>Shipping Address</u></i></b></td>
			</tr>
		<br>
		<tr>
			
		<td>Name:<?php echo $name ;?></td>
			</tr>
		<br>
			<tr>
		
	    <td>Phone No:<?php echo $phone ; ?></td>
			</tr>
		<br>
			<tr>
		<td>Email:<?php echo  $email ; ?></td>
			</tr>
		<br>
			<tr>
		<td>Address:<?php echo $add; ?></td>
			</tr>
		<br>
		<tr>
		
	<td> <img src="https://chart.googleapis.com/chart?chs=100x100&cht=qr&chl=<?php echo "hi  $name for the event";
		                                                                           
		                                                                           echo "  $eventname $n seats are booked which is on";
			                                                                       
		                                                                         			  
		                                                                           echo  "  $eventstart held at";
			                                                                       
		                                                                           echo " $eventvenue";
			  
		                                                                         
		                                                                        
		                                                                           echo "  and total price for this is $p";
		                                                                        
		                                                                           
		                                                                      ?>&choe=UTF-8" title="Link to Google.com" /> </td>
		</tr>
	</table>
	
</body>
	</html>	