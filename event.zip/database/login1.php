<?php
session_start();
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname= "event_organization";
$conn = new mysqli($servername, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_GET['username'];
$password = $_GET['password'];
   
$sql1 = "SELECT * FROM members WHERE `username` = '$username' and password = '$password'";
    $result =mysqli_query($conn,$sql1);
    if ($row = mysqli_fetch_assoc($result)) {
		$_SESSION['mid']=$row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['password'] = $row['password'];
		
		
		header("Location:book.php");
	}
		
    
else {
        echo "Incorrect Email or Password!!!";
    }

	?> 