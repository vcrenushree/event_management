<html>
	<title>BOOKING</title>
<body background="5.jpg" >
	<div align="center" >
		<?php
	$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";



$conn = new mysqli($servername, $user, $pass, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

		
?>
		<div align="right">
		<a href="logout.php">LogOut</a>
		</div>
	
		
		<form action="" method="get">
		<br><br><br><br><br><br><br><br><br><br><br><br><br>
		
			<h4>Enter no. of seats:</h4>
		         <input type="number" name="book" /><br>
				    <input type="submit" name="submit" />
	  </form>		
	</div>	
	
	<?php
session_start();
	if(isset($_GET['submit'])){
$eid=$_SESSION['event_id'];
$memberid=$_SESSION['mid'];
$n=$_GET['book'];
//echo $eid;
//echo $memberid;
//echo $n;
if( $n > 5 )
{
	echo "not allowed";
//header("location:book.php");
}
else{

$r=mysqli_query($conn,"select ticketprice from events where eventid='$eid'");
while($arr=mysqli_fetch_array($r))
{
    $tprice=$arr[0];
}

$p = $n * $tprice;

	// $result = $conn->query($r);
	 
		 //$event_name=$array['eventname'];

   
		 $res=mysqli_query($conn,"select * from events where eventid='$eid'");
	while($array=mysqli_fetch_array($res)) {
		$eventname=$array[1];
		$eventstart=$array[5];
		$eventvenue=$array[4];
	}
	$re=mysqli_query($conn,"select * from members where id='$memberid'");
	while($arra=mysqli_fetch_array($re)) {
		$name=$arra[1];
		
	}
	
	
	
	echo "hi $name ";?>
	<br>
	<?php
	
	 echo "your tickets has been successfully booked for the"; ?>
	<br> <?php echo"event $eventname";?>
	<br><?php echo "which is held on $eventstart";?>
	<br><?php echo "at $eventvenue";?>
	<br>
	<?php
	 echo "Number of seats booked=$n";
	?><br>
    <?php echo "Total price =$p";
	
	
	

$sql = mysqli_query($conn,"INSERT INTO booktickets (eventid,memberid,no_of_seats,price) VALUES ($eid,$memberid,$n,$p)");
$sql = mysqli_query($conn,"UPDATE events SET seatsavailable=seatsavailable-$n where eventid='$eid'");
}
		}
	
?>
</body>
</html>
