<?php
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";



$conn = new mysqli($servername, $user, $pass, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
    $ename = $_POST['name'];
    $organizer = $_POST['oragnizer'];
    $description = $_POST['description'];
    $venue = $_POST['venue'];
    $start = $_POST['startdate'];
    $end = $_POST['enddate'];
    $wurl=$_POST['wurl'];
    $ticket = $_POST['ticket'];
    $num1 = $_POST['num1'];
    $num2 = $_POST['num2'];
    $num3=$_POST['num3'];
    $seats = $_POST['seats'];
    $terms = $_POST['terms'];
    $url = $_POST['url'];
   $banner = $_POST['banner'];
$sql = "INSERT INTO events (eventname, eventorganizer, description, venue, eventstart, eventendate, eventwebsiteurl, ticketprice, contactno1, contactno2, contactno3, seatsavailable, terms, bookingurl,eventbanner)
    VALUES ('$ename', '$organizer', '$description','$venue','$start','$end', '$wurl','$ticket', '$num1','$num2','$num3', '$seats','$terms','$url','$banner')";
    if ($conn->query($sql) === TRUE) {
        echo "Event Added";
        header('Location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    ?> 