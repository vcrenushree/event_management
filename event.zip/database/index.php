<!DOCTYPE html>
<html lang="en">
<head>
  <title>HOME</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style>
		
		hr {
    display: block;
    height: 50px;
    border: 0;
    border-top: 1px solid #ccc;
    margin: 1em 0;
    padding: 0; 
			color: black;
			
}
	</style>
</head>
	
<body background="3.jpg"  >


<?php
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";



$conn = new mysqli($servername, $user, $pass, $dbname);
	

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql1 = "SELECT * FROM events  ";
   $result = $conn->query($sql1);
	 while($array=mysqli_fetch_row($result)) 
	{
		
		$var=$array[0];
	
	?>
	
<div class="container">
  <div class="row">
    <div class="col-sm-8">
	<div><h3><b>EventName:</b></h3><?php echo $array[1]; ?> </div><br>
	<div><h3><b>Description:</b></h3><?php echo $array[3]; ?></div><br>
    <div><h3><b>Venue:</b></h3><?php echo $array[4]; ?></div><br>
    <div><h3><b>EventStartDate:</b></h3><?php echo $array[5]; ?></div><br>
    <div><h3><b>EventEndDate:</b></h3><?php echo $array[6]; ?></div><br>
   </div>
 <div class="col-sm-4">
	
      <div id = "<?php $array ?>"> <h3><b>EventImage:</b></h3><br><img src= " <?php echo $array[15];?> " > </div><br>
		   <a href="details.php?id= <?php  echo $var; ?>" >Click here for more details</a>
	 </div>
  </div>
</div>
	<hr >
		<?php } 
$conn->close();
	?>
	
</body>
</html>