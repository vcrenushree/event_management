-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: event_organization
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'The Great Music Summit 2017 ','Pradeep','A perfect set of playlist to couple up with your perfect drink. Rock it a bit. Swing to the rock and hit the floor hard. ',' GreenBubbles Startup Services\nNo.L-165, 1st floor, Sri Gayathri complex, Near Bhagavathi Hospital, Service Rd, Sector 6, HSR Layout, Bengaluru, Karnataka 560102\n','2017-05-18','2017-05-18','https://www.eventshigh.com/detail/bangalore/24ffa45c11312c8a0fdff452d98c0c10-the-great-music-summit-2017','100','9876543210','08192-250065','08192-264000',100,'Tickets once purchased is non-refundable under any circumstances','0','/database/music.jpeg'),(2,'Shikhandi','Hina Thadani','The National Centre for Performing Arts (NCPA) presents one of their hugely successful and evocative plays - Shikhandi ',' Ranga Shankara\nRanga Shankara, No. 36/2, 8th Cross Road, JP Nagar, 2nd Phase Bengaluru, Karnataka 560078 ','2017-05-20','2017-05-20','https://www.eventshigh.com/detail/Bangalore/8ebcbe1ea606581adb57a79a429ab4ef-shikhandi-the-story-of-the?src=stream','300','7896543210','8899776655','9123456780',150,'Outside Food Not Allowed','0','/database/drama.jpg');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-17 11:19:07
