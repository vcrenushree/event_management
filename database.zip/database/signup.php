 <?php
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";

$name=$_POST["name"];
$lastname=$_POST["lastname"];
$email=$_POST["email"];
$phoneno=$_POST["phoneno"];
$address=$_POST["address"];
$username=$_POST["username"];
$password=$_POST["password"];



$conn = new mysqli($servername, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO members (name, lastname, email,phoneno,address,username,password)
VALUES ('$name', '$lastname', '$email','$phoneno','$address','$username','$password')";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$myfile = fopen("hi.html", "r") or die("Unable to open file!");
echo fread($myfile,filesize("hi.html"));
fclose($myfile);


$conn->close();


  
?> 

			