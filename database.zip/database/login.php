<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root123";
$dbname= "event_organization";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully to the database";


$username = $_POST['username'];
$password = $_POST['password'];
    //echo $email;
  // echo $password;
//if (isset($_POST['login'])) {

    //$email = mysqli_real_escape_string($conn, $_POST['email']);
   // $password = mysqli_real_escape_string($conn, $_POST['password']);

//echo "hello";
$sql1 = "SELECT * FROM members WHERE `username` = '$username' and password = '$password'";
    $result =mysqli_query($conn,$sql1);
//echo"welcome";

    if ($row = mysqli_fetch_assoc($result)) {
      
		//echo $row["username"];
        //echo $row["password"];
		session_start();
		$_SESSION['mid']=$row[0];
        $_SESSION['username'] = $row['username'];
        $_SESSION['password'] = $row['password'];
        echo "Login Successfully";
		header("location:book.html");
    }
else {
        echo "Incorrect Email or Password!!!";
    }
//}
	?> 