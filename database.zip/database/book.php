 <?php
$servername = "localhost";
$user = "root";
$pass = "root123";
$dbname = "event_organization";

$conn = new mysqli($servername, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
session_start();


$eid=$_SESSION['id']; 
$memberid=$_SESSION['mid']
$n=$_GET["book"];

$r=mysqli_query($conn,"select ticketprice from events where eventid='$eid'");
while($arr=mysqli_fetch_array($r))
{
    $tprice=$arr[0];
}

$p = $n * $tprice;
echo "your tickets has been successfully booked....!";
$sql = mysqli_query($conn,"INSERT INTO booktickets (id,eventid,no_of_seats,price) VALUES ($memberid,$eid,$n,$p)");
$sql = mysqli_query($conn,"UPDATE events SET seatsavailable=seatsavailable-$n where eid=$eid");
?>





